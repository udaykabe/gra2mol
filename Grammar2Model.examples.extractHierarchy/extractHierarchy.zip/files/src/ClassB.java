package hierarchyOne.hierarchieTwo;

public class ClassB extends ClassA implements IntB, IntBB {

}