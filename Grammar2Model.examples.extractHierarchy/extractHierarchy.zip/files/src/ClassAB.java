package hierarchyOne;

public class ClassAB extends ClassA {

}