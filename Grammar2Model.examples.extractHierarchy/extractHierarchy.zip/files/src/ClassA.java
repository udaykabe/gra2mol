package hierarchyOne;

public class ClassA {

}
