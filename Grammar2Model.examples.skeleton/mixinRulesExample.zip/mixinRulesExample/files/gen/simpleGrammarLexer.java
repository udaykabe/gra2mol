// $ANTLR 3.2 Sep 23, 2009 12:02:23 simpleGrammar.g 2010-06-15 17:51:01

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class simpleGrammarLexer extends Lexer {
    public static final int WS=6;
    public static final int LINE_COMMENT=8;
    public static final int T__10=10;
    public static final int DQUOTE=5;
    public static final int DQVAL=4;
    public static final int COMMENT=7;
    public static final int EOF=-1;
    public static final int T__9=9;

    // delegates
    // delegators

    public simpleGrammarLexer() {;} 
    public simpleGrammarLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public simpleGrammarLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "simpleGrammar.g"; }

    // $ANTLR start "T__9"
    public final void mT__9() throws RecognitionException {
        try {
            int _type = T__9;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:3:6: ( 'print' )
            // simpleGrammar.g:3:8: 'print'
            {
            match("print"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__9"

    // $ANTLR start "T__10"
    public final void mT__10() throws RecognitionException {
        try {
            int _type = T__10;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:4:7: ( 'echo' )
            // simpleGrammar.g:4:9: 'echo'
            {
            match("echo"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__10"

    // $ANTLR start "DQUOTE"
    public final void mDQUOTE() throws RecognitionException {
        try {
            int _type = DQUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:151:8: ( '\\u0022' )
            // simpleGrammar.g:151:10: '\\u0022'
            {
            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DQUOTE"

    // $ANTLR start "DQVAL"
    public final void mDQVAL() throws RecognitionException {
        try {
            int _type = DQVAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:152:8: ( DQUOTE ( options {greedy=false; } : . )* DQUOTE )
            // simpleGrammar.g:152:10: DQUOTE ( options {greedy=false; } : . )* DQUOTE
            {
            mDQUOTE(); 
            // simpleGrammar.g:152:17: ( options {greedy=false; } : . )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0=='\"') ) {
                    alt1=2;
                }
                else if ( ((LA1_0>='\u0000' && LA1_0<='!')||(LA1_0>='#' && LA1_0<='\uFFFF')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // simpleGrammar.g:152:44: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            mDQUOTE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DQVAL"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:154:8: ( ( ' ' | '\\t' | '\\n' | '\\r' )+ )
            // simpleGrammar.g:154:10: ( ' ' | '\\t' | '\\n' | '\\r' )+
            {
            // simpleGrammar.g:154:10: ( ' ' | '\\t' | '\\n' | '\\r' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='\t' && LA2_0<='\n')||LA2_0=='\r'||LA2_0==' ') ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // simpleGrammar.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "COMMENT"
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:156:5: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // simpleGrammar.g:156:7: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // simpleGrammar.g:156:12: ( options {greedy=false; } : . )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='*') ) {
                    int LA3_1 = input.LA(2);

                    if ( (LA3_1=='/') ) {
                        alt3=2;
                    }
                    else if ( ((LA3_1>='\u0000' && LA3_1<='.')||(LA3_1>='0' && LA3_1<='\uFFFF')) ) {
                        alt3=1;
                    }


                }
                else if ( ((LA3_0>='\u0000' && LA3_0<=')')||(LA3_0>='+' && LA3_0<='\uFFFF')) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // simpleGrammar.g:156:40: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            match("*/"); 

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMENT"

    // $ANTLR start "LINE_COMMENT"
    public final void mLINE_COMMENT() throws RecognitionException {
        try {
            int _type = LINE_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // simpleGrammar.g:160:5: ( '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n' )
            // simpleGrammar.g:160:7: '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n'
            {
            match("//"); 

            // simpleGrammar.g:160:12: (~ ( '\\n' | '\\r' ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>='\u0000' && LA4_0<='\t')||(LA4_0>='\u000B' && LA4_0<='\f')||(LA4_0>='\u000E' && LA4_0<='\uFFFF')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // simpleGrammar.g:160:12: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // simpleGrammar.g:160:26: ( '\\r' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0=='\r') ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // simpleGrammar.g:160:26: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 
            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LINE_COMMENT"

    public void mTokens() throws RecognitionException {
        // simpleGrammar.g:1:8: ( T__9 | T__10 | DQUOTE | DQVAL | WS | COMMENT | LINE_COMMENT )
        int alt6=7;
        alt6 = dfa6.predict(input);
        switch (alt6) {
            case 1 :
                // simpleGrammar.g:1:10: T__9
                {
                mT__9(); 

                }
                break;
            case 2 :
                // simpleGrammar.g:1:15: T__10
                {
                mT__10(); 

                }
                break;
            case 3 :
                // simpleGrammar.g:1:21: DQUOTE
                {
                mDQUOTE(); 

                }
                break;
            case 4 :
                // simpleGrammar.g:1:28: DQVAL
                {
                mDQVAL(); 

                }
                break;
            case 5 :
                // simpleGrammar.g:1:34: WS
                {
                mWS(); 

                }
                break;
            case 6 :
                // simpleGrammar.g:1:37: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 7 :
                // simpleGrammar.g:1:45: LINE_COMMENT
                {
                mLINE_COMMENT(); 

                }
                break;

        }

    }


    protected DFA6 dfa6 = new DFA6(this);
    static final String DFA6_eotS =
        "\3\uffff\1\6\6\uffff";
    static final String DFA6_eofS =
        "\12\uffff";
    static final String DFA6_minS =
        "\1\11\2\uffff\1\0\1\uffff\1\52\4\uffff";
    static final String DFA6_maxS =
        "\1\160\2\uffff\1\uffff\1\uffff\1\57\4\uffff";
    static final String DFA6_acceptS =
        "\1\uffff\1\1\1\2\1\uffff\1\5\1\uffff\1\3\1\4\1\6\1\7";
    static final String DFA6_specialS =
        "\3\uffff\1\0\6\uffff}>";
    static final String[] DFA6_transitionS = {
            "\2\4\2\uffff\1\4\22\uffff\1\4\1\uffff\1\3\14\uffff\1\5\65\uffff"+
            "\1\2\12\uffff\1\1",
            "",
            "",
            "\0\7",
            "",
            "\1\10\4\uffff\1\11",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA6_eot = DFA.unpackEncodedString(DFA6_eotS);
    static final short[] DFA6_eof = DFA.unpackEncodedString(DFA6_eofS);
    static final char[] DFA6_min = DFA.unpackEncodedStringToUnsignedChars(DFA6_minS);
    static final char[] DFA6_max = DFA.unpackEncodedStringToUnsignedChars(DFA6_maxS);
    static final short[] DFA6_accept = DFA.unpackEncodedString(DFA6_acceptS);
    static final short[] DFA6_special = DFA.unpackEncodedString(DFA6_specialS);
    static final short[][] DFA6_transition;

    static {
        int numStates = DFA6_transitionS.length;
        DFA6_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA6_transition[i] = DFA.unpackEncodedString(DFA6_transitionS[i]);
        }
    }

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = DFA6_eot;
            this.eof = DFA6_eof;
            this.min = DFA6_min;
            this.max = DFA6_max;
            this.accept = DFA6_accept;
            this.special = DFA6_special;
            this.transition = DFA6_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__9 | T__10 | DQUOTE | DQVAL | WS | COMMENT | LINE_COMMENT );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA6_3 = input.LA(1);

                        s = -1;
                        if ( ((LA6_3>='\u0000' && LA6_3<='\uFFFF')) ) {s = 7;}

                        else s = 6;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 6, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}