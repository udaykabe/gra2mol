package hierarchyOne.hierarchieTwo;

public interface IntBB extends IntBB {

}