// $ANTLR 3.2 Sep 23, 2009 12:02:23 simpleGrammar.g 2010-06-15 17:52:04

	import gts.modernization.model.CST.impl.*;
	import gts.modernization.model.CST.*;
	import java.util.Iterator;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.antlr.stringtemplate.*;
import org.antlr.stringtemplate.language.*;
import java.util.HashMap;
/** 
 * An example grammar for a simple language
 */
public class simpleGrammarParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "NUMBER", "DQUOTE", "DQVAL", "WS", "COMMENT", "LINE_COMMENT", "'print'", "'not'", "'and'", "'or'"
    };
    public static final int WS=7;
    public static final int LINE_COMMENT=9;
    public static final int T__12=12;
    public static final int T__11=11;
    public static final int T__13=13;
    public static final int T__10=10;
    public static final int NUMBER=4;
    public static final int DQUOTE=5;
    public static final int DQVAL=6;
    public static final int COMMENT=8;
    public static final int EOF=-1;

    // delegates
    // delegators


        public simpleGrammarParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public simpleGrammarParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected StringTemplateGroup templateLib =
      new StringTemplateGroup("simpleGrammarParserTemplates", AngleBracketTemplateLexer.class);

    public void setTemplateLib(StringTemplateGroup templateLib) {
      this.templateLib = templateLib;
    }
    public StringTemplateGroup getTemplateLib() {
      return templateLib;
    }
    /** allows convenient multi-value initialization:
     *  "new STAttrMap().put(...).put(...)"
     */
    public static class STAttrMap extends HashMap {
      public STAttrMap put(String attrName, Object value) {
        super.put(attrName, value);
        return this;
      }
      public STAttrMap put(String attrName, int value) {
        super.put(attrName, new Integer(value));
        return this;
      }
    }

    public String[] getTokenNames() { return simpleGrammarParser.tokenNames; }
    public String getGrammarFileName() { return "simpleGrammar.g"; }


    public static class mainRule_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "mainRule"
    // simpleGrammar.g:22:1: mainRule returns [Node returnNode] : (statementGen+= statement )* ;
    public final simpleGrammarParser.mainRule_return mainRule() throws RecognitionException {
        simpleGrammarParser.mainRule_return retval = new simpleGrammarParser.mainRule_return();
        retval.start = input.LT(1);

        List list_statementGen=null;
        RuleReturnScope statementGen = null;
        try {
            // simpleGrammar.g:23:1: ( (statementGen+= statement )* )
            // simpleGrammar.g:23:4: (statementGen+= statement )*
            {
            // simpleGrammar.g:23:16: (statementGen+= statement )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==10) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // simpleGrammar.g:0:0: statementGen+= statement
            	    {
            	    pushFollow(FOLLOW_statement_in_mainRule49);
            	    statementGen=statement();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if (list_statementGen==null) list_statementGen=new ArrayList();
            	    list_statementGen.add(statementGen);


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node mainRuleReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		mainRuleReturnNode.setKind("mainRule");
              	    // Create a CST Node
              		if(list_statementGen != null) {
              	        for(Iterator it = list_statementGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.statement_return r = (simpleGrammarParser.statement_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("statement");
              	            	mainRuleReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = mainRuleReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "mainRule"

    public static class statement_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "statement"
    // simpleGrammar.g:44:1: statement returns [Node returnNode] : print_statementGen+= print_statement ;
    public final simpleGrammarParser.statement_return statement() throws RecognitionException {
        simpleGrammarParser.statement_return retval = new simpleGrammarParser.statement_return();
        retval.start = input.LT(1);

        List list_print_statementGen=null;
        RuleReturnScope print_statementGen = null;
        try {
            // simpleGrammar.g:45:1: (print_statementGen+= print_statement )
            // simpleGrammar.g:45:4: print_statementGen+= print_statement
            {
            pushFollow(FOLLOW_print_statement_in_statement75);
            print_statementGen=print_statement();

            state._fsp--;
            if (state.failed) return retval;
            if (list_print_statementGen==null) list_print_statementGen=new ArrayList();
            list_print_statementGen.add(print_statementGen);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node statementReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		statementReturnNode.setKind("statement");
              	    // Create a CST Node
              		if(list_print_statementGen != null) {
              	        for(Iterator it = list_print_statementGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.print_statement_return r = (simpleGrammarParser.print_statement_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("print_statement");
              	            	statementReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = statementReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class print_statement_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "print_statement"
    // simpleGrammar.g:65:1: print_statement returns [Node returnNode] : TK_0= 'print' expressionGen+= expression ;
    public final simpleGrammarParser.print_statement_return print_statement() throws RecognitionException {
        simpleGrammarParser.print_statement_return retval = new simpleGrammarParser.print_statement_return();
        retval.start = input.LT(1);

        Token TK_0=null;
        List list_expressionGen=null;
        RuleReturnScope expressionGen = null;
        try {
            // simpleGrammar.g:66:1: (TK_0= 'print' expressionGen+= expression )
            // simpleGrammar.g:66:4: TK_0= 'print' expressionGen+= expression
            {
            TK_0=(Token)match(input,10,FOLLOW_10_in_print_statement98); if (state.failed) return retval;
            pushFollow(FOLLOW_expression_in_print_statement103);
            expressionGen=expression();

            state._fsp--;
            if (state.failed) return retval;
            if (list_expressionGen==null) list_expressionGen=new ArrayList();
            list_expressionGen.add(expressionGen);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node print_statementReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		print_statementReturnNode.setKind("print_statement");
              	    // Create a Token CST Leaf	
              	    if(TK_0 != null) {
              			Leaf TK_0Leaf = CSTFactoryImpl.eINSTANCE.createLeaf("TOKEN", (TK_0!=null?TK_0.getText():null), TK_0.getCharPositionInLine(), TK_0.getLine());
              	 		print_statementReturnNode.getChildren().add(TK_0Leaf);
              	 	}
              	    // Create a CST Node
              		if(list_expressionGen != null) {
              	        for(Iterator it = list_expressionGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.expression_return r = (simpleGrammarParser.expression_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("expression");
              	            	print_statementReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = print_statementReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "print_statement"

    public static class expression_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "expression"
    // simpleGrammar.g:91:1: expression returns [Node returnNode] : (TK_0= 'not' )? andExpressionGen+= andExpression ;
    public final simpleGrammarParser.expression_return expression() throws RecognitionException {
        simpleGrammarParser.expression_return retval = new simpleGrammarParser.expression_return();
        retval.start = input.LT(1);

        Token TK_0=null;
        List list_andExpressionGen=null;
        RuleReturnScope andExpressionGen = null;
        try {
            // simpleGrammar.g:92:1: ( (TK_0= 'not' )? andExpressionGen+= andExpression )
            // simpleGrammar.g:92:3: (TK_0= 'not' )? andExpressionGen+= andExpression
            {
            // simpleGrammar.g:92:3: (TK_0= 'not' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // simpleGrammar.g:92:5: TK_0= 'not'
                    {
                    TK_0=(Token)match(input,11,FOLLOW_11_in_expression127); if (state.failed) return retval;

                    }
                    break;

            }

            pushFollow(FOLLOW_andExpression_in_expression134);
            andExpressionGen=andExpression();

            state._fsp--;
            if (state.failed) return retval;
            if (list_andExpressionGen==null) list_andExpressionGen=new ArrayList();
            list_andExpressionGen.add(andExpressionGen);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node expressionReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		expressionReturnNode.setKind("expression");
              	    // Create a Token CST Leaf	
              	    if(TK_0 != null) {
              			Leaf TK_0Leaf = CSTFactoryImpl.eINSTANCE.createLeaf("TOKEN", (TK_0!=null?TK_0.getText():null), TK_0.getCharPositionInLine(), TK_0.getLine());
              	 		expressionReturnNode.getChildren().add(TK_0Leaf);
              	 	}
              	    // Create a CST Node
              		if(list_andExpressionGen != null) {
              	        for(Iterator it = list_andExpressionGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.andExpression_return r = (simpleGrammarParser.andExpression_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("andExpression");
              	            	expressionReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = expressionReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class andExpression_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "andExpression"
    // simpleGrammar.g:117:1: andExpression returns [Node returnNode] : orExpressionGen+= orExpression (TK_0= 'and' orExpressionGen_1+= orExpression )* ;
    public final simpleGrammarParser.andExpression_return andExpression() throws RecognitionException {
        simpleGrammarParser.andExpression_return retval = new simpleGrammarParser.andExpression_return();
        retval.start = input.LT(1);

        Token TK_0=null;
        List list_orExpressionGen=null;
        List list_orExpressionGen_1=null;
        RuleReturnScope orExpressionGen = null;
        RuleReturnScope orExpressionGen_1 = null;
        try {
            // simpleGrammar.g:118:1: (orExpressionGen+= orExpression (TK_0= 'and' orExpressionGen_1+= orExpression )* )
            // simpleGrammar.g:118:4: orExpressionGen+= orExpression (TK_0= 'and' orExpressionGen_1+= orExpression )*
            {
            pushFollow(FOLLOW_orExpression_in_andExpression158);
            orExpressionGen=orExpression();

            state._fsp--;
            if (state.failed) return retval;
            if (list_orExpressionGen==null) list_orExpressionGen=new ArrayList();
            list_orExpressionGen.add(orExpressionGen);

            // simpleGrammar.g:118:34: (TK_0= 'and' orExpressionGen_1+= orExpression )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==12) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // simpleGrammar.g:118:36: TK_0= 'and' orExpressionGen_1+= orExpression
            	    {
            	    TK_0=(Token)match(input,12,FOLLOW_12_in_andExpression164); if (state.failed) return retval;
            	    pushFollow(FOLLOW_orExpression_in_andExpression169);
            	    orExpressionGen_1=orExpression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if (list_orExpressionGen_1==null) list_orExpressionGen_1=new ArrayList();
            	    list_orExpressionGen_1.add(orExpressionGen_1);


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node andExpressionReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		andExpressionReturnNode.setKind("andExpression");
              	    // Create a CST Node
              		if(list_orExpressionGen != null) {
              	        for(Iterator it = list_orExpressionGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.orExpression_return r = (simpleGrammarParser.orExpression_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("orExpression");
              	            	andExpressionReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }

              		// Create a special CST Node for terminal orExpressionGen_1 aggregation
              		if(list_orExpressionGen_1 != null) {
              	    for(int pos = 0; pos < list_orExpressionGen_1.size(); pos++ )  { 
              	    // Create a Token CST Leaf	
              	    if(TK_0 != null) {
              			Leaf TK_0Leaf = CSTFactoryImpl.eINSTANCE.createLeaf("TOKEN", (TK_0!=null?TK_0.getText():null), TK_0.getCharPositionInLine(), TK_0.getLine());
              	 		andExpressionReturnNode.getChildren().add(TK_0Leaf);
              	 	}
              		// No Terminal extractor
              	    if(list_orExpressionGen_1 != null) {		
              	    	simpleGrammarParser.orExpression_return r = (simpleGrammarParser.orExpression_return) list_orExpressionGen_1.get(pos); 
              	    	if(r != null && r.returnNode != null) {
              	        	r.returnNode.setKind("orExpression");
              	    		andExpressionReturnNode.getChildren().add(r.returnNode);
              	    	} 
              		}
              		}
              		}

              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = andExpressionReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "andExpression"

    public static class orExpression_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "orExpression"
    // simpleGrammar.g:158:1: orExpression returns [Node returnNode] : unaryExpressionGen+= unaryExpression (TK_0= 'or' unaryExpressionGen_1+= unaryExpression )* ;
    public final simpleGrammarParser.orExpression_return orExpression() throws RecognitionException {
        simpleGrammarParser.orExpression_return retval = new simpleGrammarParser.orExpression_return();
        retval.start = input.LT(1);

        Token TK_0=null;
        List list_unaryExpressionGen=null;
        List list_unaryExpressionGen_1=null;
        RuleReturnScope unaryExpressionGen = null;
        RuleReturnScope unaryExpressionGen_1 = null;
        try {
            // simpleGrammar.g:159:1: (unaryExpressionGen+= unaryExpression (TK_0= 'or' unaryExpressionGen_1+= unaryExpression )* )
            // simpleGrammar.g:159:4: unaryExpressionGen+= unaryExpression (TK_0= 'or' unaryExpressionGen_1+= unaryExpression )*
            {
            pushFollow(FOLLOW_unaryExpression_in_orExpression196);
            unaryExpressionGen=unaryExpression();

            state._fsp--;
            if (state.failed) return retval;
            if (list_unaryExpressionGen==null) list_unaryExpressionGen=new ArrayList();
            list_unaryExpressionGen.add(unaryExpressionGen);

            // simpleGrammar.g:159:40: (TK_0= 'or' unaryExpressionGen_1+= unaryExpression )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==13) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // simpleGrammar.g:159:42: TK_0= 'or' unaryExpressionGen_1+= unaryExpression
            	    {
            	    TK_0=(Token)match(input,13,FOLLOW_13_in_orExpression202); if (state.failed) return retval;
            	    pushFollow(FOLLOW_unaryExpression_in_orExpression207);
            	    unaryExpressionGen_1=unaryExpression();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if (list_unaryExpressionGen_1==null) list_unaryExpressionGen_1=new ArrayList();
            	    list_unaryExpressionGen_1.add(unaryExpressionGen_1);


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node orExpressionReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		orExpressionReturnNode.setKind("orExpression");
              	    // Create a CST Node
              		if(list_unaryExpressionGen != null) {
              	        for(Iterator it = list_unaryExpressionGen.iterator(); it.hasNext(); )  { 
              	            simpleGrammarParser.unaryExpression_return r = (simpleGrammarParser.unaryExpression_return) it.next(); 
              	            if(r != null && r.returnNode != null) {
              	            	r.returnNode.setKind("unaryExpression");
              	            	orExpressionReturnNode.getChildren().add(r.returnNode);
              	            } 
              	        }
              	    }

              		// Create a special CST Node for terminal unaryExpressionGen_1 aggregation
              		if(list_unaryExpressionGen_1 != null) {
              	    for(int pos = 0; pos < list_unaryExpressionGen_1.size(); pos++ )  { 
              	    // Create a Token CST Leaf	
              	    if(TK_0 != null) {
              			Leaf TK_0Leaf = CSTFactoryImpl.eINSTANCE.createLeaf("TOKEN", (TK_0!=null?TK_0.getText():null), TK_0.getCharPositionInLine(), TK_0.getLine());
              	 		orExpressionReturnNode.getChildren().add(TK_0Leaf);
              	 	}
              		// No Terminal extractor
              	    if(list_unaryExpressionGen_1 != null) {		
              	    	simpleGrammarParser.unaryExpression_return r = (simpleGrammarParser.unaryExpression_return) list_unaryExpressionGen_1.get(pos); 
              	    	if(r != null && r.returnNode != null) {
              	        	r.returnNode.setKind("unaryExpression");
              	    		orExpressionReturnNode.getChildren().add(r.returnNode);
              	    	} 
              		}
              		}
              		}

              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = orExpressionReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "orExpression"

    public static class unaryExpression_return extends ParserRuleReturnScope {
        public Node returnNode;
        public StringTemplate st;
        public Object getTemplate() { return st; }
        public String toString() { return st==null?null:st.toString(); }
    };

    // $ANTLR start "unaryExpression"
    // simpleGrammar.g:199:1: unaryExpression returns [Node returnNode] : NUMBERGen= NUMBER ;
    public final simpleGrammarParser.unaryExpression_return unaryExpression() throws RecognitionException {
        simpleGrammarParser.unaryExpression_return retval = new simpleGrammarParser.unaryExpression_return();
        retval.start = input.LT(1);

        Token NUMBERGen=null;

        try {
            // simpleGrammar.g:200:1: (NUMBERGen= NUMBER )
            // simpleGrammar.g:200:4: NUMBERGen= NUMBER
            {
            NUMBERGen=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_unaryExpression231); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

              		// Create return CST Node
              		Node unaryExpressionReturnNode = CSTFactoryImpl.eINSTANCE.createNode();
              		unaryExpressionReturnNode.setKind("unaryExpression");
              	    // Create a CST Leaf
              		if(NUMBERGen != null) {
              			Leaf NUMBERGenLeaf = CSTFactoryImpl.eINSTANCE.createLeaf("NUMBER", (NUMBERGen!=null?NUMBERGen.getText():null), NUMBERGen.getCharPositionInLine(), NUMBERGen.getLine());
              			unaryExpressionReturnNode.getChildren().add(NUMBERGenLeaf);
              		}
              		// Returns the Node with CST Leaves/Nodes
              		retval.returnNode = unaryExpressionReturnNode;
              	
            }

            }

            retval.stop = input.LT(-1);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unaryExpression"

    // Delegated rules


 

    public static final BitSet FOLLOW_statement_in_mainRule49 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_print_statement_in_statement75 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_10_in_print_statement98 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_expression_in_print_statement103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_expression127 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_andExpression_in_expression134 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_orExpression_in_andExpression158 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_12_in_andExpression164 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_orExpression_in_andExpression169 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_unaryExpression_in_orExpression196 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_13_in_orExpression202 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_unaryExpression_in_orExpression207 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_NUMBER_in_unaryExpression231 = new BitSet(new long[]{0x0000000000000002L});

}