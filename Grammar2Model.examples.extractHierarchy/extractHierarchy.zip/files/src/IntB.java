package hierarchyOne.hierarchieTwo;

public interface IntB {

}