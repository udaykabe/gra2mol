package hierarchyOne;

public class ClassAA extends ClassA {

}